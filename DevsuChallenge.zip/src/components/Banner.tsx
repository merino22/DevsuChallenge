import React from "react";

const Banner: React.FC<any> = ({}) => {
    return (
        <div>
            <h1 className="">BANCO PICHINCHA</h1>
        </div>
    );
};

export default Banner;