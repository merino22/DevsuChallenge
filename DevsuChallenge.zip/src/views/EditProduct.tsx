import React, { useEffect, useState } from 'react';
import CreateProduct from './CreateProduct';

interface CreateProductProps {
    onSubmit: (newProduct: any) => void;
}

const EditProduct: React.FC<CreateProductProps> = ({ 
        onSubmit
    }) => {

    const deserializeProduct = () => {
        try {
            const serializedProduct = localStorage.getItem('itemToEdit');
            if (serializedProduct !== null) {
                return JSON.parse(serializedProduct);
            }
        } catch (error) {
            console.log('Error trying to edit product: ', error);
        }
    }

    const retrievedProduct = deserializeProduct();

    const [productData, setProductData] = useState<any>({
        id: retrievedProduct.id,
        name: retrievedProduct.name,
        description: retrievedProduct.description,
        logo: retrievedProduct.logo,
        date_release: retrievedProduct.dateRelease,
        date_revision: retrievedProduct.dateRevision
    });

    return (
        <div>
            <CreateProduct onSubmit={onSubmit} productData={productData} checked={true}/>
        </div>
    )
}

export default EditProduct;